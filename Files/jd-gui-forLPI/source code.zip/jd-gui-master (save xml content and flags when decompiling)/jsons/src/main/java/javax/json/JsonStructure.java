package javax.json;

public interface JsonStructure extends JsonValue {}


/* Location:              C:\User\\user\Downloads\javax.json-1.0.jar!\javax\json\JsonStructure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */