package javax.json.stream;

public interface JsonLocation {
  long getLineNumber();
  
  long getColumnNumber();
  
  long getStreamOffset();
}


/* Location:              C:\User\\user\Downloads\javax.json-1.0.jar!\javax\json\stream\JsonLocation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */