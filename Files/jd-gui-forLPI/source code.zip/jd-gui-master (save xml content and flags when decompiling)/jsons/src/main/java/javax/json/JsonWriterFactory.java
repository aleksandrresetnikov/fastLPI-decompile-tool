package javax.json;

import java.io.OutputStream;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.Map;

public interface JsonWriterFactory {
  JsonWriter createWriter(Writer paramWriter);
  
  JsonWriter createWriter(OutputStream paramOutputStream);
  
  JsonWriter createWriter(OutputStream paramOutputStream, Charset paramCharset);
  
  Map<String, ?> getConfigInUse();
}


/* Location:              C:\User\\user\Downloads\javax.json-1.0.jar!\javax\json\JsonWriterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */