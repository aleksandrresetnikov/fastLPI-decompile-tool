package com.sane5k.lpi.utilities.data;

import com.sane5k.lpi.utilities.Helper;
import com.sane5k.lpi.utilities.model.XmlWriterForm;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.File;

public class XmlWriter implements XmlWriterForm {
    private String rootName;
    private String xmlFilePath;
    private DocumentBuilderFactory documentFactory;
    private DocumentBuilder documentBuilder;
    private Document document;
    private Element root;
    private TransformerFactory transformerFactory;
    private Transformer transformer;
    private DOMSource domSource;

    public XmlWriter(String path){
        this.rootName = new File(path).getName();
        this.xmlFilePath = path;
        this.InitXml();
    }

    protected void InitXml(){
        try {
            this.documentFactory = Helper.InstanceDocumentBuilderFactory();
            this.documentBuilder = this.documentFactory.newDocumentBuilder();
            this.document = documentBuilder.newDocument();
            this.transformerFactory = TransformerFactory.newInstance();
            this.transformer = this.transformerFactory.newTransformer();
            this.domSource = new DOMSource(this.document);

            InitXmlRoot();
        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        }

    }

    protected void InitXmlRoot(){
        this.root = this.document.createElement(this.rootName);
        this.document.appendChild(this.root);
    }

    @Override
    public void Save() {
        //System.out.println()

        StreamResult streamResult = new StreamResult(new File(this.xmlFilePath));

        try {
            transformer.transform(domSource, streamResult);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Done creating XML writing !");
    }

    @Override
    public String GetName() {
        return this.rootName;
    }

    @Override
    public Element GetRoot() {
        return this.root;
    }

    @Override
    public TransformerFactory GetTransformerFactory() {
        return this.transformerFactory;
    }

    @Override
    public Transformer GetTransformer() {
        return this.transformer;
    }

    @Override
    public DOMSource GetDomSource() {
        return this.domSource;
    }

    @Override
    public String GetXmlFilePath() {
        return this.xmlFilePath;
    }

    @Override
    public DocumentBuilderFactory GetDocumentFactory() {
        return this.documentFactory;
    }

    @Override
    public DocumentBuilder GetDocumentBuilder() {
        return this.documentBuilder;
    }

    @Override
    public Document GetDocument() {
        return this.document;
    }

    @Override
    public void AppendChild(Element element) {
        this.root.appendChild(element);
    }
}
