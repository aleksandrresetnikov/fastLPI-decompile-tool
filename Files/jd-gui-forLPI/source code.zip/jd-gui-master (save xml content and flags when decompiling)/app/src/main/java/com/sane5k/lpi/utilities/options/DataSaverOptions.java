package com.sane5k.lpi.utilities.options;

import com.sane5k.lpi.utilities.Helper;
import com.sane5k.lpi.utilities.model.DataSaverOptionsForm;
import org.jd.gui.api.model.TreeNodeData;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

public class DataSaverOptions implements DataSaverOptionsForm {
    public String outPath;
    public String inputPath;
    public DefaultMutableTreeNode root;

    public DataSaverOptions(DefaultMutableTreeNode root, String inputPath, String outPath){
        this.outPath = outPath;
        this.inputPath = inputPath;
        this.root = root;
    }

    @Override
    public String getOutPath() {
        return outPath;
    }

    @Override
    public String getInputPath() {
        return inputPath;
    }

    @Override
    public DefaultMutableTreeNode getRoot() {
        return root;
    }

    @Override
    public DefaultMutableTreeNode GetDefaultMutableTreeNode() {
        return Helper.GetDefaultMutableTreeNode(new DefaultMutableTreeNode());
    }

    @Override
    public TreeNodeData GetTreeNodeData() {
        return null;
    }
}
