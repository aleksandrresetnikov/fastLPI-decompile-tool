package com.sane5k.lpi.utilities.options;

public class XmlOptions {
    public String RootNode = "Root node";
    public String FileName = "MyFile.jar";
}
