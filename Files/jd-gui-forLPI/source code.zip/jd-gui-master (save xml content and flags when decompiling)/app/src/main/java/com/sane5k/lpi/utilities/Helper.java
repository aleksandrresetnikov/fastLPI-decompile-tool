package com.sane5k.lpi.utilities;

import org.jd.gui.api.model.Container;
import org.jd.gui.api.model.TreeNodeData;
import org.jd.gui.view.component.Tree;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.xml.parsers.DocumentBuilderFactory;

import java.nio.file.ProviderNotFoundException;
import java.util.Enumeration;

public class Helper {
    public static DefaultMutableTreeNode GetDefaultMutableTreeNode(TreeNode node){
        return (DefaultMutableTreeNode)(node);
    }

    public static TreeNodeData GetTreeNodeData(DefaultMutableTreeNode mutableNode){
        return (TreeNodeData)(mutableNode.getUserObject());
    }

    public static void ExpandAllTreeRow(Tree tree){
        for (int i = 0; i < tree.getRowCount(); i++) {
            tree.expandRow(i);
        }
    }

    public static void visitAllNodes(TreeNode root) {
        visitAllNodes(root, "");
    }

    public static void visitAllNodes(JTree tree) {
        TreeNode root = (TreeNode) tree.getModel().getRoot();
        visitAllNodes(root, "");
    }

    public static void visitAllNodes(TreeNode node, String tab) {
        try {
            DefaultMutableTreeNode mutableNode = GetDefaultMutableTreeNode(node);
            TreeNodeData nodeData = GetTreeNodeData(mutableNode);

            System.out.println(tab+nodeData.getLabel());
        } catch (Exception ex){

        }

        if (node.getChildCount() >= 0) {
            for (Enumeration e = node.children(); e.hasMoreElements();) {
                TreeNode n = (TreeNode) e.nextElement();
                visitAllNodes(n, tab + "-");
            }
        }
    }

    public static void VisitAllAntrys(Container.Entry entry, String tab) {
        try {
            System.out.println(tab+entry.getPath());

            for (Container.Entry _entry : entry.getChildren()) {
                VisitAllAntrys(_entry, tab + "-");
            }
        } catch (ProviderNotFoundException ex){

        }
    }

    public static DocumentBuilderFactory InstanceDocumentBuilderFactory(){
        return DocumentBuilderFactory.newInstance();
    }

    public static String XmlFormating(String value){
        return value.replace(" ", "ъ")
                    .replace(",", "й")
                    .replace("(", "Ѣ")
                    .replace(")", "Ѡ")
                    .replace("[", "Ѵ")
                    .replace("]", "Ѳ")
                    .replace(":", "Ѥ");
    }
}
