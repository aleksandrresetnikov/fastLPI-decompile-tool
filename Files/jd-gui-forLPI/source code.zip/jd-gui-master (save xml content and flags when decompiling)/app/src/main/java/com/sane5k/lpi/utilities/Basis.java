package com.sane5k.lpi.utilities;

import com.sane5k.lpi.utilities.data.TreeNodeDataSaverManager;
import com.sane5k.lpi.utilities.model.DataSaverOptionsForm;
import com.sane5k.lpi.utilities.model.TreeNodeDataSaverManagerForm;
import com.sane5k.lpi.utilities.options.DataSaverOptions;

import javax.swing.tree.DefaultMutableTreeNode;

public class Basis {
    public static void SaveJarData(DefaultMutableTreeNode root, String inputPath, String outPath){
        try {
            DataSaverOptionsForm saverOptions = new DataSaverOptions(root, inputPath, outPath);
            TreeNodeDataSaverManagerForm treeNodeDataSaverManager = new TreeNodeDataSaverManager(saverOptions);
            treeNodeDataSaverManager.Save();
        } catch (Exception e){
            e.printStackTrace();
            System.out.println("The process of saving jar is a problem.");

            return;
        } finally {
            System.exit(0);
        }

        System.out.println("jar saving process - done.");
    }
}
