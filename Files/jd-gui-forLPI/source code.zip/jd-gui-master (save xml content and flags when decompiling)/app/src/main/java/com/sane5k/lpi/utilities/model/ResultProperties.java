package com.sane5k.lpi.utilities.model;

public interface ResultProperties {
    long GetSaveTime();
    String GetInputPath();
    String GetOutputPath();
    String GetFileName();

    void SetSaveTime(long value);
    void SetInputPath(String value);
    void SetOutputPath(String value);
}
