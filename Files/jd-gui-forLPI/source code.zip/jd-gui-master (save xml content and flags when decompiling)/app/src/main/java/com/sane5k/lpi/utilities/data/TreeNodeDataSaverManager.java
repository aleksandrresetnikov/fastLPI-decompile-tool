package com.sane5k.lpi.utilities.data;

import com.sane5k.lpi.utilities.FormManager;
import com.sane5k.lpi.utilities.Helper;
import com.sane5k.lpi.utilities.model.ResultProperties;
import com.sane5k.lpi.utilities.model.XmlWriterForm;
import com.sane5k.lpi.utilities.model.DataSaverOptionsForm;
import com.sane5k.lpi.utilities.model.TreeNodeDataSaverManagerForm;

import org.jd.gui.api.model.TreeNodeData;
import org.w3c.dom.Element;

import javax.swing.tree.DefaultMutableTreeNode;
import java.io.FileNotFoundException;
import java.util.Enumeration;

public class TreeNodeDataSaverManager implements TreeNodeDataSaverManagerForm {
    private FormManager FormHelperManager;

    protected DataSaverOptionsForm saverOptions;
    protected ResultProperties savingResultProperties;
    protected XmlWriterForm xmlWriter;

    public TreeNodeDataSaverManager(DataSaverOptionsForm saverOptions) {
        this.FormHelperManager = new FormManager();

        this.saverOptions = saverOptions;
        this.CreateXmlWriter();
    }
    protected void CreateXmlWriter() {
        try {
            this.xmlWriter = FormHelperManager.CreateJsonWriter(this.saverOptions.getOutPath());
        } catch (FileNotFoundException e) {

        }
    }

    @Override
    public DataSaverOptionsForm GetSaverOptions() {
        return this.saverOptions;
    }

    @Override
    public XmlWriterForm GetXmlWriter() {
        return this.xmlWriter;
    }

    @Override
    public ResultProperties GetSavingResultProperties() {
        return this.savingResultProperties;
    }

    @Override
    public void Save() {
        long time = System.currentTimeMillis();
        SavingProcess();
        this.savingResultProperties = this.FormHelperManager.CreateDataSavingResultProperties(System.currentTimeMillis() - time,
                this.saverOptions.getInputPath(), this.saverOptions.getOutPath());
        SavingResultPropertiesProcess();
        this.xmlWriter.Save();
        System.out.println("Saving time: " + this.savingResultProperties.GetSaveTime());
    }
    protected void SavingProcess(){
        System.out.println("Saving to: "+this.saverOptions.getOutPath());
        //Helper.visitAllNodes(this.saverOptions.getRoot());
        StartRecursiveIteration(this.saverOptions.getRoot());
    }
    protected void SavingResultPropertiesProcess(){
        Element rootSavingResultPropertiesElement = this.GetXmlWriter().GetRoot();
        Element resultPropertiesElement = this.GetXmlWriter().GetDocument().createElement("_____LPI_DATA_SAVING_SAVE_PROPERTIES_____");

        rootSavingResultPropertiesElement.appendChild(resultPropertiesElement);
        resultPropertiesElement.setAttribute("Affiliation", "TreeNodeDataSaverManager");

        Element savingTime = this.GetXmlWriter().GetDocument().createElement("SavingTime");
        savingTime.setAttribute("value", String.valueOf(this.savingResultProperties.GetSaveTime()));

        Element inputPath = this.GetXmlWriter().GetDocument().createElement("InputPath");
        inputPath.setAttribute("value", this.savingResultProperties.GetInputPath());

        Element outPath = this.GetXmlWriter().GetDocument().createElement("OutputPath");
        outPath.setAttribute("value", this.savingResultProperties.GetOutputPath());

        Element fileName = this.GetXmlWriter().GetDocument().createElement("JarFileName");
        fileName.setAttribute("value", this.savingResultProperties.GetFileName());

        resultPropertiesElement.appendChild(savingTime);
        resultPropertiesElement.appendChild(inputPath);
        resultPropertiesElement.appendChild(outPath);
        resultPropertiesElement.appendChild(fileName);
    }

    protected void StartRecursiveIteration(DefaultMutableTreeNode rootNode){
        Element rootElement = this.GetXmlWriter().GetRoot();
        RecursiveIteration(rootNode, rootElement);
    }

    protected void RecursiveIteration(DefaultMutableTreeNode node, Element element){
        try {
            TreeNodeData nodeData = (TreeNodeData)node.getUserObject();
        } catch (Exception ex){

        }
        if (node.getChildCount() >= 0) {
            for (Enumeration e = node.children(); e.hasMoreElements();) {
                DefaultMutableTreeNode n = (DefaultMutableTreeNode) e.nextElement();

                try {
                    TreeNodeData data = Helper.GetTreeNodeData(n);
                    String subElementLabelName = Helper.XmlFormating(data.getLabel());

                    Element subElement = this.GetXmlWriter().GetDocument().createElement(subElementLabelName);
                    subElement.setAttribute("Flags", String.valueOf(data.getFlags()));

                    element.setAttribute("Tip", data.getTip());
                    element.appendChild(subElement);

                    RecursiveIteration(n, subElement);
                } catch (Exception ex) {
                    System.out.println("Error: "+Helper.GetTreeNodeData(n).getLabel());
                }
            }
        }
    }
}
