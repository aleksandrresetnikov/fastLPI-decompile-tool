package com.sane5k.lpi.utilities.model;

import org.w3c.dom.Document;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;

public interface XmlWriterForm {
    String GetXmlFilePath();
    DocumentBuilderFactory GetDocumentFactory();
    DocumentBuilder GetDocumentBuilder();
    Document GetDocument();
    void AppendChild(Element element);
    void Save();
    String GetName();
    Element GetRoot();
    TransformerFactory GetTransformerFactory();
    Transformer GetTransformer();
    DOMSource GetDomSource();
}
