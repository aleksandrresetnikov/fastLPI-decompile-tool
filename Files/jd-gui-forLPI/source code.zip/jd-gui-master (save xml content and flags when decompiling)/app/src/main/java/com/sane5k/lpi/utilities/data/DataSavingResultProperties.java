package com.sane5k.lpi.utilities.data;

import com.sane5k.lpi.utilities.model.ResultProperties;

import java.io.File;

public class DataSavingResultProperties implements ResultProperties {
    protected long saveTime;
    protected String inputPath;
    protected String outputPath;
    protected String fileName;

    public DataSavingResultProperties(long saveTime, String inputPath, String outputPath){
        this.saveTime = saveTime;
        this.inputPath = inputPath;
        this.outputPath = outputPath;
        this.fileName = new File(this.inputPath).getName();
    }

    @Override
    public long GetSaveTime() {
        return this.saveTime;
    }

    @Override
    public String GetInputPath() {
        return this.inputPath;
    }

    @Override
    public String GetOutputPath() {
        return this.outputPath;
    }

    @Override
    public String GetFileName() {
        return this.fileName;
    }


    @Override
    public void SetSaveTime(long value) {
        this.saveTime = value;
    }

    @Override
    public void SetInputPath(String value) {
        this.inputPath = value;
    }

    @Override
    public void SetOutputPath(String value) {
        this.outputPath = value;
    }
}
