package com.sane5k.lpi.utilities.model;

public interface TreeNodeDataSaverManagerForm {
    DataSaverOptionsForm GetSaverOptions();
    XmlWriterForm GetXmlWriter();
    void Save();
    ResultProperties GetSavingResultProperties();
}
