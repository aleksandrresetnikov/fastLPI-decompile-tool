package com.sane5k.lpi.utilities;

import com.sane5k.lpi.utilities.data.DataSavingResultProperties;
import com.sane5k.lpi.utilities.data.TreeNodeDataSaverManager;
import com.sane5k.lpi.utilities.data.XmlWriter;
import com.sane5k.lpi.utilities.model.DataSaverOptionsForm;
import com.sane5k.lpi.utilities.model.XmlWriterForm;
import com.sane5k.lpi.utilities.model.TreeNodeDataSaverManagerForm;
import com.sane5k.lpi.utilities.model.ResultProperties;
import com.sane5k.lpi.utilities.options.DataSaverOptions;

import javax.swing.tree.DefaultMutableTreeNode;
import java.io.FileNotFoundException;

public class FormManager {
    public XmlWriterForm CreateJsonWriter(String path) throws FileNotFoundException {
        return new XmlWriter(path);
    }

    public TreeNodeDataSaverManagerForm CreateTreeNodeDataSaver(DataSaverOptionsForm saverOptions){
        return new TreeNodeDataSaverManager(saverOptions);
    }

    public DataSaverOptionsForm CreateSaverOptions(DefaultMutableTreeNode root, String inputPath, String outPath){
        return new DataSaverOptions(root,inputPath, outPath);
    }

    public ResultProperties CreateDataSavingResultProperties(long saveTime, String inputPath, String outputPath){
        return new DataSavingResultProperties(saveTime, inputPath, outputPath);
    }
}
