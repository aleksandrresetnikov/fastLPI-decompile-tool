package com.sane5k.lpi.utilities.model;

import org.jd.gui.api.model.TreeNodeData;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

public interface DataSaverOptionsForm {
    String getOutPath();
    String getInputPath();
    DefaultMutableTreeNode getRoot();
    DefaultMutableTreeNode GetDefaultMutableTreeNode();
    TreeNodeData GetTreeNodeData();
}
